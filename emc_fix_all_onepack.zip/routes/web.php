<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\StorefrontController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\OrderStatusController;
use App\Http\Controllers\EmpresaSwitchController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\ProductosController;
use App\Http\Controllers\Operaciones\OrdenesController;

Route::get('/', [StorefrontController::class,'index'])->name('store.index');

Route::get('/carrito', [CartController::class,'index'])->name('cart.index');
Route::post('/carrito/agregar', [CartController::class,'add'])->name('cart.add');
Route::post('/carrito', [CartController::class,'update'])->name('cart.update');
Route::post('/carrito/vaciar', [CartController::class,'clear'])->name('cart.clear');

Route::get('/checkout', [CheckoutController::class,'show'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class,'place'])->name('checkout.place');

Route::get('/pedido/{folio}/gracias', [OrderStatusController::class,'thanks'])->name('orders.thanks');
Route::get('/pedido/{folio}', [OrderStatusController::class,'track'])->name('orders.track');

Route::get('/login',[LoginController::class,'showLoginForm'])->name('login');
Route::post('/login',[LoginController::class,'login']);
Route::post('/logout',[LoginController::class,'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/empresa', [EmpresaSwitchController::class, 'index'])->name('empresa.switch');
    Route::post('/empresa', [EmpresaSwitchController::class, 'set'])->name('empresa.set');

    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::middleware(['empresa'])->group(function () {

        Route::prefix('admin')->name('admin.')->middleware(['role:admin_empresa,superadmin'])->group(function () {
            Route::get('/', [AdminDashboardController::class,'index'])->name('dashboard');

            Route::get('productos', [ProductosController::class,'index'])->name('productos.index');
            Route::get('productos/create', [ProductosController::class,'create'])->name('productos.create');
            Route::post('productos', [ProductosController::class,'store'])->name('productos.store');
            Route::get('productos/{id}/edit', [ProductosController::class,'edit'])->name('productos.edit');
            Route::put('productos/{id}', [ProductosController::class,'update'])->name('productos.update');
            Route::delete('productos/{id}', [ProductosController::class,'destroy'])->name('productos.destroy');
        });

        Route::prefix('ops')->name('ops.')->middleware(['role:operaciones,admin_empresa,superadmin'])->group(function () {
            Route::get('ordenes', [OrdenesController::class,'index'])->name('ordenes.index');
            Route::get('ordenes/{id}', [OrdenesController::class,'show'])->name('ordenes.show');
            Route::post('ordenes/{id}/status', [OrdenesController::class,'updateStatus'])->name('ordenes.status');
        });
    });
});
