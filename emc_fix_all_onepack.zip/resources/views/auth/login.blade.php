@extends('layouts.store')

@section('content')
<div class="max-w-md mx-auto rounded-xl bg-white border p-6">
  <div class="text-2xl font-semibold tracking-tight">Acceso</div>
  <div class="text-sm text-slate-500">Panel EMC · Admin / Operaciones</div>

  <form method="POST" action="/login" class="mt-5 space-y-4">
    @csrf
    <div>
      <label class="text-sm text-slate-600">Email</label>
      <input class="mt-1 w-full rounded-lg border px-3 py-2" name="email" value="{{ old('email') }}" required>
      @error('email')<div class="text-sm text-red-600 mt-1">{{ $message }}</div>@enderror
    </div>
    <div>
      <label class="text-sm text-slate-600">Password</label>
      <input class="mt-1 w-full rounded-lg border px-3 py-2" type="password" name="password" required>
      @error('password')<div class="text-sm text-red-600 mt-1">{{ $message }}</div>@enderror
    </div>

    @if($errors->any())
      <div class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-800 text-sm">{{ $errors->first() }}</div>
    @endif

    <button class="w-full rounded-lg bg-slate-900 text-white px-4 py-3 font-semibold">Entrar</button>
  </form>
</div>
@endsection
