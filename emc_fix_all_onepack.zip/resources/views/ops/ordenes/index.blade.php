@extends('layouts.admin')

@section('content')
<div class="rounded-xl bg-white border p-4">
  <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
    <div>
      <div class="text-xl font-semibold">Operaciones · Lista del día</div>
      <div class="text-sm text-slate-500">Filtra por folio o estatus</div>
    </div>

    <form class="flex flex-wrap gap-2" method="GET" action="{{ route('ops.ordenes.index') }}">
      <input class="rounded-lg border px-3 py-2 text-sm w-44" name="folio" value="{{ request('folio') }}" placeholder="Folio">
      <select class="rounded-lg border px-3 py-2 text-sm" name="status">
        <option value="">Todos</option>
        @foreach(['nuevo','confirmado','preparando','listo','en_ruta','entregado','cancelado'] as $st)
          <option value="{{ $st }}" @selected(request('status')===$st)>{{ $st }}</option>
        @endforeach
      </select>
      <label class="inline-flex items-center gap-2 text-sm text-slate-600">
        <input type="checkbox" name="all" value="1" @checked(request()->boolean('all'))>
        Ver todas
      </label>
      <button class="rounded-lg bg-slate-900 text-white px-4 py-2 text-sm">Buscar</button>
    </form>
  </div>

  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="text-left text-slate-500">
        <tr>
          <th class="py-2">Folio</th>
          <th class="py-2">Cliente</th>
          <th class="py-2">Total</th>
          <th class="py-2">Estatus</th>
          <th class="py-2">Acción</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        @foreach($ordenes as $o)
          <tr>
            <td class="py-2 font-semibold">{{ $o->folio ?? ('#'.$o->id) }}</td>
            <td class="py-2">{{ $o->comprador_nombre ?? '—' }}</td>
            <td class="py-2 font-semibold">${{ number_format($o->total,2) }}</td>
            <td class="py-2"><span class="inline-flex rounded-full bg-slate-100 px-3 py-1">{{ $o->status }}</span></td>
            <td class="py-2"><a class="text-slate-900 underline" href="{{ route('ops.ordenes.show',$o->id) }}">Ver</a></td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>

  <div class="mt-4">{{ $ordenes->links() }}</div>
</div>
@endsection
