@extends('layouts.store')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
  <section class="lg:col-span-7">
    <div class="rounded-xl bg-white border p-5">
      <div class="text-2xl font-semibold tracking-tight mb-4">Checkout</div>

      <form method="POST" action="{{ route('checkout.place') }}" class="space-y-4">
        @csrf

        <div>
          <label class="text-sm text-slate-600">Nombre</label>
          <input class="mt-1 w-full rounded-lg border px-3 py-2" name="comprador_nombre" value="{{ old('comprador_nombre') }}" required>
          @error('comprador_nombre')<div class="text-sm text-red-600 mt-1">{{ $message }}</div>@enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="text-sm text-slate-600">WhatsApp</label>
            <input class="mt-1 w-full rounded-lg border px-3 py-2" name="comprador_whatsapp" value="{{ old('comprador_whatsapp') }}" placeholder="521XXXXXXXXXX" required>
            <p class="text-xs text-slate-500 mt-1">Te notificaremos estatus por WhatsApp.</p>
            @error('comprador_whatsapp')<div class="text-sm text-red-600 mt-1">{{ $message }}</div>@enderror
          </div>
          <div>
            <label class="text-sm text-slate-600">Email (opcional)</label>
            <input class="mt-1 w-full rounded-lg border px-3 py-2" name="comprador_email" value="{{ old('comprador_email') }}">
            @error('comprador_email')<div class="text-sm text-red-600 mt-1">{{ $message }}</div>@enderror
          </div>
        </div>

        <div>
          <label class="text-sm text-slate-600">Entrega</label>
          <select class="mt-1 w-full rounded-lg border px-3 py-2" name="tipo_entrega" required>
            <option value="pickup" @selected(old('tipo_entrega')==='pickup')>Pickup</option>
            <option value="delivery" @selected(old('tipo_entrega')==='delivery')>Delivery</option>
          </select>
          @error('tipo_entrega')<div class="text-sm text-red-600 mt-1">{{ $message }}</div>@enderror
        </div>

        <div>
          <label class="text-sm text-slate-600">Nota (opcional)</label>
          <textarea class="mt-1 w-full rounded-lg border px-3 py-2" rows="3" name="nota">{{ old('nota') }}</textarea>
        </div>

        <button class="w-full rounded-lg bg-emerald-600 text-white px-4 py-3 font-semibold hover:bg-emerald-700">
          Confirmar pedido
        </button>
      </form>
    </div>
  </section>

  <aside class="lg:col-span-5">
    <div class="rounded-xl bg-white border p-5">
      <div class="font-semibold mb-3">Resumen</div>
      <div class="divide-y">
        @foreach($items as $it)
          <div class="py-3 flex justify-between text-sm">
            <div>{{ $it['qty'] }} × {{ $it['producto']->nombre }}</div>
            <div class="font-semibold">${{ number_format($it['line_total'],2) }}</div>
          </div>
        @endforeach
      </div>
      <div class="pt-4 flex justify-between text-base">
        <div class="font-semibold">Total</div>
        <div class="font-semibold">${{ number_format($total,2) }}</div>
      </div>
      <div class="pt-4">
        <a href="{{ route('cart.index') }}" class="text-sm text-slate-600 hover:underline">← Volver al carrito</a>
      </div>
    </div>
  </aside>
</div>
@endsection
