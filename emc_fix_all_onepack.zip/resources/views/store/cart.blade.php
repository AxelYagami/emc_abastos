@extends('layouts.store')

@section('header_actions')
  <a href="{{ route('store.index') }}" class="inline-flex items-center gap-2 rounded-lg border bg-white px-3 py-2 text-sm hover:bg-slate-50">
    ← Seguir comprando
  </a>
@endsection

@section('content')
<div class="rounded-xl bg-white border p-5">
  <div class="text-2xl font-semibold tracking-tight mb-4">Carrito</div>

  @if(empty($items))
    <div class="text-slate-600">Tu carrito está vacío.</div>
  @else
    <form method="POST" action="{{ route('cart.update') }}" class="space-y-3">
      @csrf
      <div class="divide-y">
        @foreach($items as $it)
          <div class="py-3 flex items-center justify-between gap-3">
            <div>
              <div class="font-semibold">{{ $it['producto']->nombre }}</div>
              <div class="text-sm text-slate-500">${{ number_format($it['producto']->precio,2) }}</div>
            </div>
            <div class="flex items-center gap-3">
              <input class="w-20 rounded-lg border px-3 py-2 text-sm" type="number" min="0" max="99"
                     name="items[{{ $it['producto']->id }}]" value="{{ $it['qty'] }}">
              <div class="w-28 text-right font-semibold">${{ number_format($it['line_total'],2) }}</div>
            </div>
          </div>
        @endforeach
      </div>

      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-4">
        <div class="text-lg font-semibold">Total: ${{ number_format($total,2) }}</div>
        <div class="flex gap-2 flex-wrap">
          <form method="POST" action="{{ route('cart.clear') }}">@csrf
            <button class="rounded-lg border px-4 py-2 text-sm hover:bg-slate-50" type="submit">Vaciar</button>
          </form>
          <button class="rounded-lg bg-slate-900 text-white px-4 py-2 text-sm" type="submit">Actualizar</button>
          <a href="{{ route('checkout.show') }}" class="rounded-lg bg-emerald-600 text-white px-4 py-2 text-sm hover:bg-emerald-700">Checkout</a>
        </div>
      </div>
    </form>
  @endif
</div>
@endsection
