@extends('layouts.store')

@section('content')
<div class="rounded-xl bg-white border p-6">
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
    <div>
      <div class="text-2xl font-semibold tracking-tight">Seguimiento</div>
      <div class="text-slate-600 text-sm">Folio: <span class="font-semibold">{{ $orden->folio ?? ('#'.$orden->id) }}</span></div>
    </div>
    <div class="text-sm">
      <span class="inline-flex rounded-full bg-slate-900 text-white px-3 py-1">{{ $orden->status }}</span>
    </div>
  </div>

  <div class="mt-5 rounded-xl border bg-slate-50 p-4">
    <div class="font-semibold mb-2">Resumen</div>
    <div class="text-sm text-slate-700">Total: <span class="font-semibold">${{ number_format($orden->total,2) }}</span></div>
    <div class="text-sm text-slate-500 mt-1">Entrega: {{ $orden->tipo_entrega ?? '—' }}</div>
  </div>

  @if($canSeePII)
    <div class="mt-4 rounded-xl border bg-slate-50 p-4">
      <div class="font-semibold mb-2">Cliente</div>
      <div class="text-sm text-slate-700">{{ $orden->comprador_nombre }}</div>
      <div class="text-sm text-slate-500">WhatsApp: {{ $orden->comprador_whatsapp }}</div>
    </div>
  @endif

  <div class="mt-4 rounded-xl border bg-slate-50 p-4">
    <div class="font-semibold mb-2">Items</div>
    <div class="divide-y">
      @foreach($orden->items as $it)
        <div class="py-2 flex justify-between text-sm">
          <div>{{ $it->cantidad }} × {{ $it->nombre }}</div>
          <div class="font-semibold">${{ number_format($it->total,2) }}</div>
        </div>
      @endforeach
    </div>
  </div>
</div>
@endsection
