<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Producto;
use App\Models\Categoria;
use Illuminate\Http\Request;

class ProductosController extends Controller
{
    public function index(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $q = Producto::query()->where('empresa_id',$empresaId)->orderByDesc('id');

        $search = trim((string)$request->get('q',''));
        if ($search !== '') {
            $search = mb_substr($search, 0, 80);
            $search = preg_replace('/[%_]+/u',' ', $search);
            $q->where('nombre','ilike',"%{$search}%");
        }

        $productos = $q->paginate(20)->withQueryString();
        return view('admin.productos.index', compact('productos','search'));
    }

    public function create(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $categorias = Categoria::where('empresa_id',$empresaId)->orderBy('id')->get();
        return view('admin.productos.create', compact('categorias'));
    }

    public function store(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $data = $request->validate([
            'nombre'=>'required|string|max:200',
            'descripcion'=>'nullable|string|max:1000',
            'categoria_id'=>'nullable|integer',
            'precio'=>'required|numeric|min:0',
            'activo'=>'required|boolean',
        ]);
        $data['empresa_id'] = $empresaId;

        Producto::create($data);
        return redirect()->route('admin.productos.index')->with('ok','Producto creado');
    }

    public function edit(Request $request, int $id)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $producto = Producto::where('empresa_id',$empresaId)->findOrFail($id);
        $categorias = Categoria::where('empresa_id',$empresaId)->orderBy('id')->get();
        return view('admin.productos.edit', compact('producto','categorias'));
    }

    public function update(Request $request, int $id)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $producto = Producto::where('empresa_id',$empresaId)->findOrFail($id);

        $data = $request->validate([
            'nombre'=>'required|string|max:200',
            'descripcion'=>'nullable|string|max:1000',
            'categoria_id'=>'nullable|integer',
            'precio'=>'required|numeric|min:0',
            'activo'=>'required|boolean',
        ]);

        $producto->update($data);
        return redirect()->route('admin.productos.index')->with('ok','Producto actualizado');
    }

    public function destroy(Request $request, int $id)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $producto = Producto::where('empresa_id',$empresaId)->findOrFail($id);
        $producto->delete();
        return redirect()->route('admin.productos.index')->with('ok','Producto eliminado');
    }
}
