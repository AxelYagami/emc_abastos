<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;

class CartController extends Controller
{
    private function getCart(Request $request): array
    {
        return $request->session()->get('cart_v2', ['empresa_id' => null, 'items' => []]);
    }

    private function putCart(Request $request, array $cart): void
    {
        $request->session()->put('cart_v2', $cart);
    }

    public function index(Request $request)
    {
        $cart = $this->getCart($request);
        $items = [];
        $total = 0;

        if (!empty($cart['items'])) {
            $products = Producto::whereIn('id', array_keys($cart['items']))->get()->keyBy('id');
            foreach ($cart['items'] as $pid => $qty) {
                $p = $products->get((int)$pid);
                if (!$p) continue;
                $line = (float)$p->precio * (int)$qty;
                $total += $line;
                $items[] = ['producto'=>$p, 'qty'=>(int)$qty, 'line_total'=>$line];
            }
        }

        return view('store.cart', compact('items','total'));
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'producto_id' => 'required|integer',
            'qty' => 'nullable|integer|min:1|max:99',
        ]);

        $p = Producto::findOrFail($data['producto_id']);
        $qty = (int)($data['qty'] ?? 1);

        $cart = $this->getCart($request);

        // Enforce single-empresa cart
        if (!empty($cart['empresa_id']) && (int)$cart['empresa_id'] !== (int)$p->empresa_id) {
            $cart = ['empresa_id' => (int)$p->empresa_id, 'items' => []];
        }
        if (empty($cart['empresa_id'])) $cart['empresa_id'] = (int)$p->empresa_id;

        $items = (array)($cart['items'] ?? []);
        $items[$p->id] = (int)($items[$p->id] ?? 0) + $qty;
        $cart['items'] = $items;

        $this->putCart($request, $cart);

        return back()->with('ok','Agregado al carrito');
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'items' => 'required|array',
            'items.*' => 'integer|min:0|max:99',
        ]);

        $cart = $this->getCart($request);
        $items = [];
        foreach ($data['items'] as $pid => $qty) {
            $qty = (int)$qty;
            if ($qty > 0) $items[(int)$pid] = $qty;
        }
        $cart['items'] = $items;

        if (empty($items)) $cart = ['empresa_id'=>null,'items'=>[]];

        $this->putCart($request, $cart);
        return redirect()->route('cart.index')->with('ok','Carrito actualizado');
    }

    public function clear(Request $request)
    {
        $request->session()->forget('cart_v2');
        return redirect()->route('cart.index')->with('ok','Carrito limpio');
    }
}
