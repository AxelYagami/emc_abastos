<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $cart = session('cart', []);
        $items = [];
        $total = 0;

        if (!empty($cart)) {
            $productos = Producto::whereIn('id', array_keys($cart))->get()->keyBy('id');
            foreach ($cart as $pid => $qty) {
                $p = $productos->get((int)$pid);
                if (!$p) continue;
                $items[] = ['producto' => $p, 'qty' => (int)$qty];
                $total += ((float)$p->precio) * (int)$qty;
            }
        }

        return view('store.cart', compact('items','total'));
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'producto_id' => ['required','integer'],
            'qty' => ['nullable','integer','min:1','max:999'],
        ]);

        $empresaId = session('empresa_id');
        if (!$empresaId) {
            return redirect()->route('empresa.switch')->withErrors(['empresa' => 'Selecciona una empresa antes de agregar productos.']);
        }

        $p = Producto::findOrFail($data['producto_id']);

        // Validate empresa + activo
        if ((int)$p->empresa_id !== (int)$empresaId) {
            return back()->withErrors(['producto_id' => 'Este producto pertenece a otra empresa.']);
        }
        if (property_exists($p, 'activo') && !$p->activo) {
            return back()->withErrors(['producto_id' => 'Este producto está inactivo.']);
        }

        $qty = (int)($data['qty'] ?? 1);

        $cartEmpresa = session('cart_empresa_id');
        if ($cartEmpresa && (int)$cartEmpresa !== (int)$empresaId) {
            // Switching empresa: clean cart to prevent cross-empresa mixes
            session()->forget('cart');
            session()->forget('cart_empresa_id');
        }

        $cart = session('cart', []);
        $cart[$p->id] = ($cart[$p->id] ?? 0) + $qty;

        session(['cart' => $cart, 'cart_empresa_id' => $empresaId]);

        return redirect()->route('cart.index');
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'producto_id' => ['required','integer'],
            'qty' => ['required','integer','min:1','max:999'],
        ]);

        $cart = session('cart', []);
        if (!isset($cart[$data['producto_id']])) return back();

        $cart[$data['producto_id']] = (int)$data['qty'];
        session(['cart' => $cart]);

        return redirect()->route('cart.index');
    }

    public function clear(Request $request)
    {
        session()->forget('cart');
        session()->forget('cart_empresa_id');
        return redirect()->route('cart.index');
    }
}
