<?php

namespace App\Http\Controllers;

use App\Models\Orden;
use App\Models\OrdenItem;
use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CheckoutController extends Controller
{
    public function show()
    {
        $cart = session('cart', []);
        if (empty($cart)) {
            return redirect()->route('cart.index')->withErrors(['cart' => 'Tu carrito está vacío.']);
        }
        return view('store.checkout');
    }

    public function place(Request $request)
    {
        $request->validate([
            'comprador_nombre' => ['required','string','max:120'],
            'comprador_whatsapp' => ['required','string','max:40'],
            'comprador_email' => ['nullable','email','max:150'],
            'tipo_entrega' => ['nullable','in:pickup,delivery'],
        ]);

        $empresaId = session('empresa_id');
        if (!$empresaId) {
            return redirect()->route('empresa.switch')->withErrors(['empresa' => 'Selecciona una empresa antes de comprar.']);
        }

        $cart = session('cart', []);
        if (empty($cart)) {
            return redirect()->route('cart.index')->withErrors(['cart' => 'Tu carrito está vacío.']);
        }

        // Load products & validate same empresa + active
        $productos = Producto::whereIn('id', array_keys($cart))->get()->keyBy('id');

        foreach ($cart as $pid => $qty) {
            $p = $productos->get((int)$pid);
            if (!$p) return back()->withErrors(['cart' => 'Producto inválido.'])->withInput();
            if ((int)$p->empresa_id !== (int)$empresaId) {
                return back()->withErrors(['cart' => 'Tu carrito contiene productos de otra empresa. Vacía el carrito y vuelve a intentar.']);
            }
            if (property_exists($p, 'activo') && !$p->activo) {
                return back()->withErrors(['cart' => 'Tu carrito contiene productos inactivos.'])->withInput();
            }
            if ($qty < 1) return back()->withErrors(['cart' => 'Cantidad inválida.'])->withInput();
        }

        return DB::transaction(function () use ($request, $empresaId, $cart, $productos) {

            // Unique folio
            do {
                $folio = 'EMC-'.strtoupper(Str::random(10));
            } while (Orden::where('folio', $folio)->exists());

            $subtotal = 0;
            foreach ($cart as $pid => $qty) {
                $p = $productos->get((int)$pid);
                $subtotal += ((float)$p->precio) * ((int)$qty);
            }

            $orden = Orden::create([
                'empresa_id' => $empresaId,
                'usuario_id' => auth()->id(),
                'folio' => $folio,
                'status' => 'creada',
                'tipo_entrega' => $request->input('tipo_entrega','pickup'),
                'comprador_nombre' => $request->input('comprador_nombre'),
                'comprador_whatsapp' => $request->input('comprador_whatsapp'),
                'comprador_email' => $request->input('comprador_email'),
                'subtotal' => $subtotal,
                'descuento' => 0,
                'envio' => 0,
                'total' => $subtotal,
                'meta' => null,
            ]);

            foreach ($cart as $pid => $qty) {
                $p = $productos->get((int)$pid);
                $precio = (float)$p->precio;
                $total = $precio * (int)$qty;

                OrdenItem::create([
                    'orden_id' => $orden->id,
                    'empresa_id' => $empresaId,
                    'producto_id' => $p->id,
                    'nombre' => $p->nombre,
                    'precio' => $precio,
                    'cantidad' => (int)$qty,
                    'total' => $total,
                ]);
            }

            session()->forget('cart');

            return redirect()->route('store.track', $orden->folio);
        });
    }
}
