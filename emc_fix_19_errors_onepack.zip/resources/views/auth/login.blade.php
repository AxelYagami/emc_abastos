@extends('layouts.app')

@section('content')
<div class="max-w-md mx-auto p-4">
  <h1 class="text-xl font-semibold mb-4">Iniciar sesión</h1>

  @if ($errors->any())
    <div class="mb-4 rounded border p-3 text-sm">
      <ul class="list-disc pl-5">
        @foreach ($errors->all() as $e)
          <li>{{ $e }}</li>
        @endforeach
      </ul>
    </div>
  @endif

  <form method="POST" action="{{ route('login.post') }}" class="space-y-3">
    @csrf
    <div>
      <label class="block text-sm font-medium mb-1">Email</label>
      <input class="w-full border rounded p-2" name="email" type="email" value="{{ old('email') }}" required autofocus>
    </div>
    <div>
      <label class="block text-sm font-medium mb-1">Contraseña</label>
      <input class="w-full border rounded p-2" name="password" type="password" required>
    </div>
    <button class="w-full px-4 py-2 rounded bg-black text-white">Entrar</button>
  </form>

  <p class="text-xs opacity-70 mt-4">
    Si no tienes credenciales, solicita acceso al administrador de tu empresa.
  </p>
</div>
@endsection
