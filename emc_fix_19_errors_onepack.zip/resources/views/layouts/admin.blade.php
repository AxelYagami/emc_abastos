<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>@yield('title','Admin') - EMC</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body class="min-h-screen bg-gray-50">
  <header class="bg-white border-b">
    <div class="max-w-6xl mx-auto p-4 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <a href="{{ route('admin.dashboard') }}" class="font-semibold">EMC Admin</a>
        <span class="text-xs opacity-70">
          Empresa:
          {{ session('empresa_nombre') ?? '—' }}
        </span>
      </div>
      <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button class="text-sm underline">Salir</button>
      </form>
    </div>
  </header>

  <main>
    @yield('content')
  </main>
</body>
</html>
