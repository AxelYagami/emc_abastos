<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>@yield('title','Tienda') - EMC</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body class="min-h-screen bg-white">
  <header class="border-b">
    <div class="max-w-6xl mx-auto p-4 flex items-center justify-between">
      <a href="{{ route('store.home') }}" class="font-semibold">EMC Abastos</a>
      <div class="flex items-center gap-3 text-sm">
        <a class="underline" href="{{ route('cart.index') }}">Carrito</a>
        <a class="underline" href="{{ route('empresa.switch') }}">Empresa</a>
        @auth
          <a class="underline" href="{{ route('admin.dashboard') }}">Admin</a>
        @else
          <a class="underline" href="{{ route('login') }}">Login</a>
        @endauth
      </div>
    </div>
  </header>

  <main>
    @yield('content')
  </main>
</body>
</html>
