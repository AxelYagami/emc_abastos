@extends('layouts.store')

@section('content')
<div class="max-w-3xl mx-auto p-4">
  <h1 class="text-xl font-semibold mb-4">Checkout</h1>

  @if ($errors->any())
    <div class="mb-4 rounded border p-3">
      <ul class="list-disc pl-5 text-sm">
        @foreach ($errors->all() as $e)
          <li>{{ $e }}</li>
        @endforeach
      </ul>
    </div>
  @endif

  <form method="POST" action="{{ route('checkout.place') }}" class="space-y-4">
    @csrf

    <div>
      <label class="block text-sm font-medium mb-1">Nombre</label>
      <input class="w-full border rounded p-2" name="comprador_nombre" value="{{ old('comprador_nombre') }}" required>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
      <div>
        <label class="block text-sm font-medium mb-1">WhatsApp</label>
        <input class="w-full border rounded p-2" name="comprador_whatsapp" value="{{ old('comprador_whatsapp') }}" placeholder="+52..." required>
      </div>
      <div>
        <label class="block text-sm font-medium mb-1">Email</label>
        <input class="w-full border rounded p-2" name="comprador_email" type="email" value="{{ old('comprador_email') }}">
      </div>
    </div>

    <div>
      <label class="block text-sm font-medium mb-1">Tipo de entrega</label>
      <select class="w-full border rounded p-2" name="tipo_entrega">
        <option value="pickup" @selected(old('tipo_entrega','pickup')==='pickup')>Pickup</option>
        <option value="delivery" @selected(old('tipo_entrega')==='delivery')>Delivery</option>
      </select>
      <p class="text-xs opacity-70 mt-1">La empresa se toma de tu selección actual (no se acepta por input).</p>
    </div>

    <div class="pt-2">
      <button class="px-4 py-2 rounded bg-black text-white">Confirmar pedido</button>
    </div>
  </form>
</div>
@endsection
