@extends('layouts.store')

@section('content')
<div class="max-w-5xl mx-auto p-4">
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-semibold">Carrito</h1>

    <form method="POST" action="{{ route('cart.clear') }}">
      @csrf
      <button class="text-sm underline" type="submit">Vaciar</button>
    </form>
  </div>

  @if(session('cart') && count(session('cart')))
    <div class="space-y-3">
      @foreach($items as $it)
        <div class="border rounded p-3 flex items-center justify-between gap-3">
          <div>
            <div class="font-medium">{{ $it['producto']->nombre }}</div>
            <div class="text-xs opacity-70">${{ number_format($it['producto']->precio,2) }}</div>
          </div>
          <form class="flex items-center gap-2" method="POST" action="{{ route('cart.update') }}">
            @csrf
            <input type="hidden" name="producto_id" value="{{ $it['producto']->id }}">
            <input class="w-20 border rounded p-2" name="qty" value="{{ $it['qty'] }}" inputmode="numeric">
            <button class="border rounded px-3 py-2 text-sm">Actualizar</button>
          </form>
        </div>
      @endforeach
    </div>

    <div class="mt-4 flex items-center justify-between">
      <div class="text-lg font-semibold">Total: ${{ number_format($total,2) }}</div>
      <a class="px-4 py-2 rounded bg-black text-white" href="{{ route('checkout.show') }}">Ir a pagar</a>
    </div>
  @else
    <div class="border rounded p-4">Tu carrito está vacío.</div>
  @endif
</div>
@endsection
