param(
    [string]$Root = "C:\sites\emc_abastos\current",
    [string]$Php = "C:\php\php.exe"
)

Write-Host "== EMC Hotfix: add route name store.index =="

$routes = Join-Path $Root "routes\web.php"
if (!(Test-Path $routes)) {
  Write-Error "routes/web.php not found at $routes"
  exit 1
}

$content = Get-Content $routes -Raw

# If already defined, do nothing
if ($content -match "name\(\s*['""]store\.index['""]\s*\)") {
  Write-Host "OK: store.index already present"
} else {
  # Try to find the homepage route to StoreController
  $pattern = "Route::get\(\s*['""]/['""]\s*,\s*\[\s*StoreController::class\s*,\s*['""]index['""]\s*\]\s*\)\s*;"
  if ($content -match $pattern) {
    $content = [regex]::Replace($content, $pattern, "Route::get('/', [StoreController::class, 'index'])->name('store.index');", 1)
    Write-Host "Patched existing StoreController index route -> name('store.index')"
  } else {
    # Insert at top after opening php tag and use statements (safe-ish)
    $insert = "Route::get('/', [\App\Http\Controllers\StoreController::class, 'index'])->name('store.index');`r`n"
    if ($content -match "<\?php") {
      # Insert after the first line
      $lines = $content -split "(`r`n|`n)"
      $new = @()
      $done = $false
      for ($i=0; $i -lt $lines.Length; $i++) {
        $new += $lines[$i]
        if (-not $done -and $lines[$i] -match "<\?php") {
          $new += ""
          $new += "// EMC hotfix: ensure named route for storefront home"
          $new += $insert.TrimEnd()
          $done = $true
        }
      }
      $content = ($new -join "`r`n")
      Write-Host "Inserted new named route store.index at top of routes/web.php"
    } else {
      Write-Error "Unexpected routes/web.php format (missing <?php)."
      exit 1
    }
  }

  Set-Content -Path $routes -Value $content -Encoding UTF8
}

# Clear route cache etc
Write-Host "Clearing caches..."
& $Php artisan route:clear | Out-Host
& $Php artisan optimize:clear | Out-Host

Write-Host "DONE. Reload /"
