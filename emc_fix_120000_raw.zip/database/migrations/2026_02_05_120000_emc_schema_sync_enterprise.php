<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * EMC schema sync (PostgreSQL, ultra-defensivo)
 * - NO usa Schema builder (evita hasTable/hasColumn dentro de transacciones abortadas)
 * - Corre FUERA de transacción (para que se vea el error real si algo falla)
 * - Usa ALTER TABLE ... ADD COLUMN IF NOT EXISTS y CREATE INDEX IF NOT EXISTS
 *
 * Nota: si alguna tabla NO existe, las sentencias están envueltas con to_regclass().
 */
return new class extends Migration
{
    public bool $withinTransaction = false;

    public function up(): void
    {
        // helper: run SQL best-effort
        $run = function(string $sql) {
            DB::statement($sql);
        };

        // categorias
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.categorias') IS NOT NULL THEN
    ALTER TABLE categorias ADD COLUMN IF NOT EXISTS activa boolean DEFAULT true;
    ALTER TABLE categorias ADD COLUMN IF NOT EXISTS slug varchar(190);
    ALTER TABLE categorias ADD COLUMN IF NOT EXISTS orden integer;
    CREATE INDEX IF NOT EXISTS idx_categorias_empresa ON categorias (empresa_id);
  END IF;
END $$;
SQL);

        // productos
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.productos') IS NOT NULL THEN
    ALTER TABLE productos ADD COLUMN IF NOT EXISTS categoria_id bigint;
    ALTER TABLE productos ADD COLUMN IF NOT EXISTS sku varchar(80);
    ALTER TABLE productos ADD COLUMN IF NOT EXISTS descripcion text;
    ALTER TABLE productos ADD COLUMN IF NOT EXISTS meta jsonb;
    ALTER TABLE productos ADD COLUMN IF NOT EXISTS activo boolean DEFAULT true;
    CREATE INDEX IF NOT EXISTS idx_productos_empresa ON productos (empresa_id);
    CREATE INDEX IF NOT EXISTS idx_productos_empresa_categoria ON productos (empresa_id, categoria_id);
    CREATE INDEX IF NOT EXISTS idx_productos_empresa_created ON productos (empresa_id, created_at);
  END IF;
END $$;
SQL);

        // ordenes
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.ordenes') IS NOT NULL THEN
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS folio varchar(60);
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS tipo_entrega varchar(30);
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS comprador_nombre varchar(180);
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS comprador_whatsapp varchar(30);
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS comprador_email varchar(190);
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS subtotal numeric(12,2) DEFAULT 0;
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS descuento numeric(12,2) DEFAULT 0;
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS envio numeric(12,2) DEFAULT 0;
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS meta jsonb;
    ALTER TABLE ordenes ADD COLUMN IF NOT EXISTS tracking_token varchar(120);
    CREATE INDEX IF NOT EXISTS idx_ordenes_empresa_created ON ordenes (empresa_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_ordenes_empresa_status_created ON ordenes (empresa_id, status, created_at);
  END IF;
END $$;
SQL);

        // orden_items
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.orden_items') IS NOT NULL THEN
    ALTER TABLE orden_items ADD COLUMN IF NOT EXISTS empresa_id bigint;
    ALTER TABLE orden_items ADD COLUMN IF NOT EXISTS nombre varchar(220);
    ALTER TABLE orden_items ADD COLUMN IF NOT EXISTS total numeric(12,2) DEFAULT 0;
    CREATE INDEX IF NOT EXISTS idx_orden_items_empresa_orden ON orden_items (empresa_id, orden_id);
  END IF;
END $$;
SQL);

        // orden_pagos
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.orden_pagos') IS NOT NULL THEN
    ALTER TABLE orden_pagos ADD COLUMN IF NOT EXISTS empresa_id bigint;
    ALTER TABLE orden_pagos ADD COLUMN IF NOT EXISTS status varchar(30) DEFAULT 'pendiente';
    ALTER TABLE orden_pagos ADD COLUMN IF NOT EXISTS referencia varchar(120);
    ALTER TABLE orden_pagos ADD COLUMN IF NOT EXISTS actor_usuario_id bigint;
    CREATE INDEX IF NOT EXISTS idx_orden_pagos_empresa_orden ON orden_pagos (empresa_id, orden_id);
    CREATE INDEX IF NOT EXISTS idx_orden_pagos_empresa_created ON orden_pagos (empresa_id, created_at);
  END IF;
END $$;
SQL);

        // caja_turnos
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.caja_turnos') IS NOT NULL THEN
    ALTER TABLE caja_turnos ADD COLUMN IF NOT EXISTS abierto_at timestamp;
    ALTER TABLE caja_turnos ADD COLUMN IF NOT EXISTS cerrado_at timestamp;
    ALTER TABLE caja_turnos ADD COLUMN IF NOT EXISTS status varchar(30) DEFAULT 'abierto';
    ALTER TABLE caja_turnos ADD COLUMN IF NOT EXISTS meta jsonb;
    CREATE INDEX IF NOT EXISTS idx_caja_turnos_empresa_created ON caja_turnos (empresa_id, created_at);
  END IF;
END $$;
SQL);

        // caja_movimientos
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.caja_movimientos') IS NOT NULL THEN
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS empresa_id bigint;
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS tipo varchar(30);
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS metodo varchar(30);
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS orden_id bigint;
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS orden_pago_id bigint;
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS actor_usuario_id bigint;
    ALTER TABLE caja_movimientos ADD COLUMN IF NOT EXISTS nota varchar(255);
    CREATE INDEX IF NOT EXISTS idx_caja_movs_empresa_created ON caja_movimientos (empresa_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_caja_movs_empresa_metodo_created ON caja_movimientos (empresa_id, metodo, created_at);
  END IF;
END $$;
SQL);

        // whatsapp_logs
        $run(<<<'SQL'
DO $$
BEGIN
  IF to_regclass('public.whatsapp_logs') IS NOT NULL THEN
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS empresa_id bigint;
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS canal varchar(30);
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS template varchar(80);
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS evento varchar(80);
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS skipped_reason varchar(120);
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS payload jsonb;
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS provider_response jsonb;
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS error text;
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS orden_id bigint;
    ALTER TABLE whatsapp_logs ADD COLUMN IF NOT EXISTS entrega_id bigint;
    CREATE INDEX IF NOT EXISTS idx_walog_empresa_created ON whatsapp_logs (empresa_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_walog_empresa_evento_created ON whatsapp_logs (empresa_id, evento, created_at);
  END IF;
END $$;
SQL);
    }

    public function down(): void {}
};
