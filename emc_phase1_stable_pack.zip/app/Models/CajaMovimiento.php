<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CajaMovimiento extends Model
{
    protected $table = 'caja_movimientos';
    protected $guarded = [];
    protected $casts = [
        'meta' => 'array',
    ];

    public function turno() { return $this->belongsTo(CajaTurno::class, 'turno_id'); }
}
