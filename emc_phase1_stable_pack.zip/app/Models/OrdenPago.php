<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrdenPago extends Model
{
    protected $table = 'orden_pagos';
    protected $guarded = [];
    protected $casts = [
        'meta' => 'array',
    ];

    public function orden() { return $this->belongsTo(Orden::class, 'orden_id'); }
}
