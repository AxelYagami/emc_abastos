@extends('layouts.store')

@section('content')
<div class="max-w-6xl mx-auto px-4 py-6">
  <div class="flex items-center justify-between">
    <h1 class="text-xl font-semibold">EMC Abastos</h1>
    <a href="{{ url('/') }}" class="text-sm underline">Inicio</a>
  </div>

  @if(isset($empresa))
    <p class="text-sm text-gray-600 mt-2">Empresa: <strong>{{ $empresa->nombre ?? '—' }}</strong></p>
  @endif

  <div class="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
    @forelse(($productos ?? []) as $p)
      <div class="border rounded-lg p-3">
        <div class="font-medium text-sm">{{ $p->nombre }}</div>
        <div class="text-xs text-gray-600 mt-1">${{ number_format($p->precio ?? 0, 2) }}</div>
        <form method="POST" action="{{ route('cart.add') }}" class="mt-2">
          @csrf
          <input type="hidden" name="producto_id" value="{{ $p->id }}">
          <input type="hidden" name="qty" value="1">
          <button class="w-full border rounded py-1 text-sm">Agregar</button>
        </form>
      </div>
    @empty
      <div class="col-span-2 md:col-span-4 text-sm text-gray-600">
        No hay productos aún. Entra al admin para crear productos.
      </div>
    @endforelse
  </div>

  <div class="mt-6 flex gap-3">
    <a class="underline text-sm" href="{{ route('cart.show') }}">Ver carrito</a>
    <a class="underline text-sm" href="{{ route('login') }}">Login</a>
  </div>
</div>
@endsection
