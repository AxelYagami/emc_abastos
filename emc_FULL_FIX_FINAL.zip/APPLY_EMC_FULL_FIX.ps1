
param(
    [string]$Root = "C:\sites\emc_abastos\current",
    [string]$Php  = "C:\php\php.exe"
)

Write-Host "== EMC FULL FIX FINAL ==" -ForegroundColor Cyan

# Ensure bootstrap/cache exists and is writable
$cachePath = Join-Path $Root "bootstrap\cache"
if (!(Test-Path $cachePath)) {
    New-Item -ItemType Directory -Path $cachePath | Out-Null
}
icacls $cachePath /grant "Users:(OI)(CI)M" /T /C | Out-Null

# Restore store.home route
$routes = Join-Path $Root "routes\web.php"
(Get-Content $routes) |
ForEach-Object {
    $_ -replace '^//\s*Route::get\(''/'', "Route::get('/'"
} | Set-Content $routes

# Remove admin.dashboard redirect usage
(Get-Content $routes) |
ForEach-Object {
    $_ -replace "route\('admin.dashboard'\)", "route('store.home')"
} | Set-Content $routes

# Disable Cliente model usage
$dashCtrl = Join-Path $Root "app\Http\Controllers\Admin\DashboardController.php"
if (Test-Path $dashCtrl) {
    (Get-Content $dashCtrl) |
    ForEach-Object {
        $_ -replace 'use App\\Models\\Cliente;', '// use App\Models\Cliente;'
    } | Set-Content $dashCtrl
}

# Clear Laravel caches
& $Php "$Root\artisan" optimize:clear

Write-Host "FIX COMPLETED. Re-test / , /login , /admin" -ForegroundColor Green
