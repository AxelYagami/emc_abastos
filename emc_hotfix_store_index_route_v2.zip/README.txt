EMC Hotfix v2 - store.index route

Ejecuta:
powershell -ExecutionPolicy Bypass -File C:\sites\emc_abastos\current\scripts\windows\05_hotfix_store_index_route.ps1 -Root "C:\sites\emc_abastos\current" -Php "C:\php\php.exe"
