param(
  [Parameter(Mandatory=$false)][string]$Root = "C:\sites\emc_abastos\current"
)

$ErrorActionPreference = "Stop"

function Ensure-Dir([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Grant-Writable([string]$Path) {
  # Grant Modify to common IIS identities + current user
  $idents = @("IIS_IUSRS","IUSR","Users")
  try { $idents += @("$env:USERNAME") } catch {}
  foreach ($id in $idents) {
    try {
      icacls $Path /grant "$id:(OI)(CI)M" /T /C | Out-Null
    } catch {
      # ignore if identity doesn't exist in this host
    }
  }
}

Write-Host "== EMC Fix: bootstrap/cache writable =="

$bootstrap = Join-Path $Root "bootstrap"
$cacheDir  = Join-Path $bootstrap "cache"
$storage   = Join-Path $Root "storage"

Ensure-Dir $bootstrap
Ensure-Dir $cacheDir

# Also ensure storage paths (Laravel commonly needs these too)
Ensure-Dir $storage
Ensure-Dir (Join-Path $storage "framework")
Ensure-Dir (Join-Path $storage "framework\cache")
Ensure-Dir (Join-Path $storage "framework\cache\data")
Ensure-Dir (Join-Path $storage "framework\sessions")
Ensure-Dir (Join-Path $storage "framework\views")
Ensure-Dir (Join-Path $storage "logs")

Grant-Writable $cacheDir
Grant-Writable $storage

Write-Host "OK. bootstrap/cache + storage are present and writable."
Write-Host "Tip: If your IIS App Pool uses a custom identity, grant it Modify too:"
Write-Host "  icacls `"$cacheDir`" /grant `"<APPPOOL\\YourPoolName>:(OI)(CI)M`" /T /C"
