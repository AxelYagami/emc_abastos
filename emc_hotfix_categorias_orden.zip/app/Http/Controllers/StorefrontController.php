<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use App\Models\Categoria;
use Illuminate\Http\Request;

class StorefrontController extends Controller
{
    public function index(Request $request)
    {
        $empresaId = (int) ($request->query('empresa_id') ?? $request->session()->get('empresa_id'));
        if (!$empresaId) {
            $empresaId = (int) (\DB::table('empresas')->orderBy('id')->value('id') ?? 0);
        }

        $q = Producto::query()
            ->where('empresa_id', $empresaId)
            ->where('activo', true)
            ->orderBy('id','desc');

        if ($cat = $request->query('cat')) {
            $q->where('categoria_id', (int)$cat);
        }
        if ($search = trim((string)$request->query('q',''))) {
            $q->where('nombre','ilike',"%{$search}%");
        }

        $productos = $q->paginate(12)->withQueryString();
        $categorias = Categoria::query()
            ->where('empresa_id',$empresaId)
            ->when(Categoria::query()->getModel()->isFillable('activa'), fn($qq) => $qq, fn($qq) => $qq)
            ->orderBy('id')
            ->get();

        // Si existe 'activa', filtramos
        try {
            $categorias = Categoria::query()
                ->where('empresa_id',$empresaId)
                ->when(\Schema::hasColumn('categorias','activa'), fn($qq)=>$qq->where('activa',true))
                ->orderBy('id')
                ->get();
        } catch (\Throwable $e) {
            // ignore schema errors
        }

        return view('store.index', compact('productos','categorias','empresaId','search','cat'));
    }
}
