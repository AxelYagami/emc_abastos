<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{{ $title ?? config('app.name','EMC Abastos') }}</title>
  @csrf
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-50">
  <header class="bg-white border-b">
    <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
      <a class="font-bold text-lg" href="{{ url('/') }}">EMC Abastos</a>
      <nav class="flex items-center gap-3 text-sm">
        <a class="px-3 py-2 rounded hover:bg-gray-100" href="{{ url('/') }}">Tienda</a>
        <a class="px-3 py-2 rounded hover:bg-gray-100" href="{{ url('/carrito') }}">Carrito</a>
        <a class="px-3 py-2 rounded hover:bg-gray-100" href="{{ url('/checkout') }}">Checkout</a>
        <a class="px-3 py-2 rounded hover:bg-gray-100" href="{{ url('/login') }}">Entrar</a>
      </nav>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 py-6">
    @if(session('status'))
      <div class="mb-4 rounded border border-green-200 bg-green-50 px-4 py-3 text-green-800">
        {{ session('status') }}
      </div>
    @endif

    @if ($errors->any())
      <div class="mb-4 rounded border border-red-200 bg-red-50 px-4 py-3 text-red-800">
        <ul class="list-disc ml-5">
          @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
        </ul>
      </div>
    @endif

    {{ $slot ?? '' }}
    @yield('content')
  </main>

  <footer class="border-t bg-white">
    <div class="max-w-6xl mx-auto px-4 py-4 text-xs text-gray-500">
      © {{ date('Y') }} EMC Abastos
    </div>
  </footer>
</body>
</html>