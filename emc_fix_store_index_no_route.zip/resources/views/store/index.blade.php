@extends('layouts.store')

@section('content')
  <div class="bg-white border rounded-lg p-6">
    <h1 class="text-2xl font-bold">Tienda</h1>
    <p class="mt-2 text-gray-600">Home cargó correctamente. Si aún no ves productos, primero corre migraciones + seed.</p>

    <div class="mt-5 flex flex-col sm:flex-row gap-3">
      <a class="inline-flex justify-center items-center rounded bg-black text-white px-4 py-2" href="{{ url('/login') }}">Entrar</a>
      <a class="inline-flex justify-center items-center rounded border px-4 py-2" href="{{ url('/carrito') }}">Ver carrito</a>
      <a class="inline-flex justify-center items-center rounded border px-4 py-2" href="{{ url('/checkout') }}">Ir a checkout</a>
    </div>
  </div>
@endsection