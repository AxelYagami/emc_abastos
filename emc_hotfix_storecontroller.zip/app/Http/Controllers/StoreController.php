<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class StoreController extends Controller
{
    /**
     * Storefront home / catálogo.
     */
    public function index(Request $request)
    {
        // Si existe una vista dedicada, úsala; si no, fallback a welcome para no 500.
        if (view()->exists('store.index')) {
            return view('store.index');
        }
        if (view()->exists('welcome')) {
            return view('welcome');
        }
        return response('EMC Abastos OK', 200);
    }

    /**
     * Detalle de producto (si existe vista).
     */
    public function producto(Request $request, $id)
    {
        // Evita reventar si el modelo no está/si no hay datos: usa DB directa con tolerancia.
        $producto = DB::table('productos')->where('id', $id)->first();

        if (!$producto) {
            abort(404);
        }

        if (view()->exists('store.producto')) {
            return view('store.producto', compact('producto'));
        }

        // Fallback mínimo.
        return response()->view('welcome', ['producto' => $producto], 200);
    }

    /**
     * Tracking público por folio: NO mostrar PII si existe orden.
     */
    public function track(Request $request, $folio)
    {
        $orden = DB::table('ordenes')->where('folio', $folio)->first();
        if (!$orden) {
            abort(404);
        }

        // Si hay vista de tracking, úsala; si no, respuesta mínima sin PII.
        if (view()->exists('store.track')) {
            return view('store.track', compact('orden'));
        }

        return response()->json([
            'folio' => $orden->folio ?? $folio,
            'status' => $orden->status ?? null,
            'total' => $orden->total ?? null,
            'created_at' => $orden->created_at ?? null,
        ]);
    }
}
