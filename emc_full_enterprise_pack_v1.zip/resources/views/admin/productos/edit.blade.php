@extends('layouts.admin', ['title'=>'Editar producto','header'=>'Editar producto'])

@section('content')
<div class="bg-white border rounded p-4">
  <form method="POST" action="{{ route('admin.productos.update',$producto->id) }}">
    @method('PUT')
    @include('admin.productos.form')
  </form>
</div>
@endsection
