@extends('layouts.admin', ['title'=>'Nuevo producto','header'=>'Nuevo producto'])

@section('content')
<div class="bg-white border rounded p-4">
  <form method="POST" action="{{ route('admin.productos.store') }}">
    @include('admin.productos.form', ['producto'=>null])
  </form>
</div>
@endsection
