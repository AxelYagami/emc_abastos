@extends('layouts.admin', ['title'=>'Caja','header'=>'Caja'])

@section('content')
<div class="grid lg:grid-cols-3 gap-4">
  <div class="bg-white border rounded p-4">
    <div class="font-semibold">Turno actual</div>
    @if($turno)
      <div class="mt-2 text-sm text-gray-600">Abierto: {{ $turno->abierto_at ?? $turno->created_at }}</div>
      <div class="mt-2">
        <a class="px-3 py-2 rounded bg-gray-900 text-white text-sm" href="{{ route('admin.caja.turno',$turno->id) }}">Ver turno</a>
      </div>
      <form method="POST" action="{{ route('admin.caja.cerrar',$turno->id) }}" class="mt-3">
        @csrf
        <button class="px-3 py-2 rounded bg-black text-white text-sm" onclick="return confirm('¿Cerrar turno?')">Cerrar turno</button>
      </form>
    @else
      <div class="mt-2 text-sm text-gray-600">No hay turno abierto.</div>
      <form method="POST" action="{{ route('admin.caja.abrir') }}" class="mt-3">
        @csrf
        <button class="px-3 py-2 rounded bg-black text-white text-sm">Abrir turno</button>
      </form>
    @endif
  </div>

  <div class="bg-white border rounded p-4 lg:col-span-2">
    <div class="font-semibold mb-3">Últimos movimientos</div>
    <div class="border rounded overflow-hidden">
      <table class="w-full text-sm">
        <thead class="bg-gray-50 border-b">
          <tr>
            <th class="text-left p-3">Fecha</th>
            <th class="text-left p-3">Tipo</th>
            <th class="text-left p-3">Método</th>
            <th class="text-right p-3">Monto</th>
            <th class="text-left p-3">Nota</th>
          </tr>
        </thead>
        <tbody class="divide-y">
          @foreach($movs as $m)
            <tr>
              <td class="p-3">{{ $m->created_at }}</td>
              <td class="p-3">{{ $m->tipo }}</td>
              <td class="p-3">{{ $m->metodo }}</td>
              <td class="p-3 text-right font-bold">${{ number_format($m->monto,2) }}</td>
              <td class="p-3 text-xs">{{ $m->nota }}</td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    <div class="mt-3">
      <a class="text-sm text-blue-700 hover:underline" href="{{ route('admin.caja.history') }}">Ver historial</a>
    </div>
  </div>
</div>
@endsection
