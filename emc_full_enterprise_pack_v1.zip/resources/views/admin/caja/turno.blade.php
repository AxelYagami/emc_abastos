@extends('layouts.admin', ['title'=>'Turno','header'=>'Turno de Caja'])

@section('content')
<div class="bg-white border rounded p-4">
  <div class="flex items-center justify-between">
    <div>
      <div class="font-bold">Turno #{{ $turno->id }}</div>
      <div class="text-sm text-gray-600">Abierto: {{ $turno->abierto_at ?? $turno->created_at }}</div>
      @if($turno->cerrado_at)<div class="text-sm text-gray-600">Cerrado: {{ $turno->cerrado_at }}</div>@endif
    </div>

    <form method="POST" action="{{ route('admin.caja.movimiento',$turno->id) }}" class="flex gap-2 items-center">
      @csrf
      <select name="tipo" class="border rounded px-2 py-2 text-sm">
        <option value="venta">Venta</option>
        <option value="ingreso">Ingreso</option>
        <option value="egreso">Egreso</option>
      </select>
      <select name="metodo" class="border rounded px-2 py-2 text-sm">
        <option value="cash">Efectivo</option>
        <option value="card">Tarjeta</option>
        <option value="transfer">Transfer</option>
      </select>
      <input name="monto" type="number" step="0.01" class="border rounded px-2 py-2 w-32 text-sm" placeholder="Monto">
      <input name="nota" class="border rounded px-2 py-2 w-56 text-sm" placeholder="Nota">
      <button class="px-3 py-2 rounded bg-black text-white text-sm">Registrar</button>
    </form>
  </div>

  <div class="mt-4 grid md:grid-cols-3 gap-3">
    @foreach($breakdown as $k => $v)
      <div class="p-3 border rounded bg-gray-50">
        <div class="text-xs text-gray-500">{{ strtoupper($k) }}</div>
        <div class="text-xl font-bold">${{ number_format($v,2) }}</div>
      </div>
    @endforeach
  </div>

  <div class="mt-4 border rounded overflow-hidden">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 border-b">
        <tr>
          <th class="text-left p-3">Fecha</th>
          <th class="text-left p-3">Tipo</th>
          <th class="text-left p-3">Método</th>
          <th class="text-right p-3">Monto</th>
          <th class="text-left p-3">Nota</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        @foreach($movs as $m)
          <tr>
            <td class="p-3">{{ $m->created_at }}</td>
            <td class="p-3">{{ $m->tipo }}</td>
            <td class="p-3">{{ $m->metodo }}</td>
            <td class="p-3 text-right font-bold">${{ number_format($m->monto,2) }}</td>
            <td class="p-3 text-xs">{{ $m->nota }}</td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
@endsection
