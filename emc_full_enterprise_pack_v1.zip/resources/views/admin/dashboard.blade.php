@extends('layouts.admin', ['title'=>'Dashboard','header'=>'Dashboard'])

@section('content')
<div class="grid lg:grid-cols-4 gap-4">
  <div class="bg-white border rounded p-4">
    <div class="text-xs text-gray-500">Ventas hoy</div>
    <div class="text-2xl font-bold mt-1">${{ number_format($kpis['ventas_hoy'],2) }}</div>
  </div>
  <div class="bg-white border rounded p-4">
    <div class="text-xs text-gray-500">Órdenes hoy</div>
    <div class="text-2xl font-bold mt-1">{{ $kpis['ordenes_hoy'] }}</div>
  </div>
  <div class="bg-white border rounded p-4">
    <div class="text-xs text-gray-500">Productos activos</div>
    <div class="text-2xl font-bold mt-1">{{ $kpis['productos_activos'] }}</div>
  </div>
  <div class="bg-white border rounded p-4">
    <div class="text-xs text-gray-500">Clientes</div>
    <div class="text-2xl font-bold mt-1">{{ $kpis['clientes'] }}</div>
  </div>
</div>

<div class="grid lg:grid-cols-2 gap-4 mt-6">
  <div class="bg-white border rounded p-4">
    <div class="font-semibold mb-3">Últimas órdenes</div>
    <div class="text-sm divide-y">
      @foreach($ultimasOrdenes as $o)
        <div class="py-2 flex items-center justify-between">
          <div>
            <div class="font-medium">{{ $o->folio ?? ('#'.$o->id) }}</div>
            <div class="text-xs text-gray-500">{{ $o->status }} · {{ $o->created_at }}</div>
          </div>
          <div class="font-bold">${{ number_format($o->total,2) }}</div>
        </div>
      @endforeach
    </div>
  </div>
  <div class="bg-white border rounded p-4">
    <div class="font-semibold mb-3">Accesos rápidos</div>
    <div class="grid sm:grid-cols-2 gap-3 text-sm">
      <a class="p-3 border rounded hover:bg-gray-50" href="{{ route('admin.productos.index') }}">Gestionar productos</a>
      <a class="p-3 border rounded hover:bg-gray-50" href="{{ route('admin.categorias.index') }}">Gestionar categorías</a>
      <a class="p-3 border rounded hover:bg-gray-50" href="{{ route('admin.caja.index') }}">Caja</a>
      <a class="p-3 border rounded hover:bg-gray-50" href="{{ route('ops.ordenes.hoy') }}">Lista del día</a>
      <a class="p-3 border rounded hover:bg-gray-50" href="{{ route('admin.whatsapp.index') }}">WhatsApp</a>
      <a class="p-3 border rounded hover:bg-gray-50" href="{{ route('admin.inventarios.index') }}">Inventario</a>
    </div>
  </div>
</div>
@endsection
