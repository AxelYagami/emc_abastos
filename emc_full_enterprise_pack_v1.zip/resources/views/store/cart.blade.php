@extends('layouts.app', ['title' => 'Carrito'])

@section('content')
<h1 class="text-xl font-bold mb-4">Carrito</h1>

@if(empty($items))
  <div class="bg-white border rounded p-6 text-gray-600">Tu carrito está vacío.</div>
@else
  <form method="POST" action="{{ route('cart.update') }}" class="bg-white border rounded overflow-hidden">
    @csrf
    <table class="w-full text-sm">
      <thead class="bg-gray-50 border-b">
        <tr>
          <th class="text-left p-3">Producto</th>
          <th class="text-right p-3">Precio</th>
          <th class="text-center p-3">Cant.</th>
          <th class="text-right p-3">Total</th>
        </tr>
      </thead>
      <tbody>
        @foreach($items as $it)
          <tr class="border-b">
            <td class="p-3">
              <a class="font-medium hover:underline" href="{{ route('store.producto', $it['producto']->id) }}">{{ $it['producto']->nombre }}</a>
            </td>
            <td class="p-3 text-right">${{ number_format($it['producto']->precio,2) }}</td>
            <td class="p-3 text-center">
              <input name="items[{{ $it['producto']->id }}]" type="number" min="0" max="99" value="{{ $it['qty'] }}"
                class="w-20 border rounded px-2 py-1 text-center">
            </td>
            <td class="p-3 text-right font-semibold">${{ number_format($it['line_total'],2) }}</td>
          </tr>
        @endforeach
      </tbody>
    </table>

    <div class="p-4 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
      <div class="text-lg font-bold">Total: ${{ number_format($total,2) }}</div>
      <div class="flex gap-2">
        <button class="px-4 py-2 rounded bg-gray-900 text-white">Actualizar</button>
        <a href="{{ route('checkout.show') }}" class="px-4 py-2 rounded bg-black text-white text-center">Checkout</a>
      </div>
    </div>
  </form>

  <form method="POST" action="{{ route('cart.clear') }}" class="mt-3">
    @csrf
    <button class="text-sm text-red-700 hover:underline">Vaciar carrito</button>
  </form>
@endif
@endsection
