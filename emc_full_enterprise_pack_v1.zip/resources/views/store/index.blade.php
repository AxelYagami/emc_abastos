@extends('layouts.app', ['title' => 'Tienda'])

@section('content')
<div class="grid md:grid-cols-4 gap-6">
  <div class="md:col-span-1">
    <form method="GET" action="{{ route('store.index') }}" class="bg-white p-4 rounded border space-y-3">
      <input type="hidden" name="empresa_id" value="{{ $empresaId }}">
      <div>
        <label class="text-xs text-gray-500">Buscar</label>
        <input name="q" value="{{ $search ?? '' }}" class="w-full mt-1 border rounded px-3 py-2" placeholder="Ej. manzana">
      </div>
      <div>
        <label class="text-xs text-gray-500">Categoría</label>
        <select name="cat" class="w-full mt-1 border rounded px-3 py-2">
          <option value="">Todas</option>
          @foreach($categorias as $c)
            <option value="{{ $c->id }}" @selected((string)request('cat')===(string)$c->id)>{{ $c->nombre }}</option>
          @endforeach
        </select>
      </div>
      <button class="w-full bg-black text-white rounded py-2">Filtrar</button>
    </form>

    <div class="mt-4 text-xs text-gray-500">
      Empresa activa: {{ $empresaId }}
    </div>
  </div>

  <div class="md:col-span-3">
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      @forelse($productos as $p)
        <div class="bg-white border rounded p-4 flex flex-col">
          <a href="{{ route('store.producto', $p->id) }}" class="font-semibold hover:underline">{{ $p->nombre }}</a>
          <div class="text-xs text-gray-500 mt-1">{{ $p->categoria?->nombre }}</div>
          <div class="mt-3 font-bold text-lg">${{ number_format($p->precio,2) }}</div>
          <form method="POST" action="{{ route('cart.add') }}" class="mt-auto pt-4">
            @csrf
            <input type="hidden" name="producto_id" value="{{ $p->id }}">
            <div class="flex gap-2">
              <input type="number" name="qty" value="1" min="1" max="99" class="w-20 border rounded px-2 py-2">
              <button class="flex-1 bg-black text-white rounded py-2">Agregar</button>
            </div>
          </form>
        </div>
      @empty
        <div class="text-gray-500">No hay productos.</div>
      @endforelse
    </div>

    <div class="mt-6">
      {{ $productos->links() }}
    </div>
  </div>
</div>
@endsection
