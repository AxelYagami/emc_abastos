@extends('layouts.app', ['title' => 'Checkout'])

@section('content')
<h1 class="text-xl font-bold mb-4">Checkout</h1>

<div class="grid md:grid-cols-2 gap-6">
  <div class="bg-white border rounded p-4">
    <h2 class="font-semibold mb-3">Resumen</h2>
    <div class="space-y-2 text-sm">
      @foreach($items as $it)
        <div class="flex justify-between">
          <div>{{ $it['producto']->nombre }} <span class="text-gray-500">x{{ $it['qty'] }}</span></div>
          <div class="font-medium">${{ number_format($it['line_total'],2) }}</div>
        </div>
      @endforeach
      <div class="border-t pt-2 flex justify-between font-bold">
        <div>Total</div>
        <div>${{ number_format($total,2) }}</div>
      </div>
    </div>
  </div>

  <div class="bg-white border rounded p-4">
    <h2 class="font-semibold mb-3">Datos</h2>

    <form method="POST" action="{{ route('checkout.place') }}" class="space-y-3">
      @csrf

      <div>
        <label class="text-xs text-gray-500">Nombre</label>
        <input name="comprador_nombre" value="{{ old('comprador_nombre') }}" class="w-full mt-1 border rounded px-3 py-2">
        @error('comprador_nombre')<div class="text-xs text-red-600 mt-1">{{ $message }}</div>@enderror
      </div>

      <div>
        <label class="text-xs text-gray-500">WhatsApp</label>
        <input name="comprador_whatsapp" value="{{ old('comprador_whatsapp') }}" class="w-full mt-1 border rounded px-3 py-2" placeholder="Ej. +52 81...">
        @error('comprador_whatsapp')<div class="text-xs text-red-600 mt-1">{{ $message }}</div>@enderror
      </div>

      <div>
        <label class="text-xs text-gray-500">Email (opcional)</label>
        <input name="comprador_email" value="{{ old('comprador_email') }}" class="w-full mt-1 border rounded px-3 py-2">
        @error('comprador_email')<div class="text-xs text-red-600 mt-1">{{ $message }}</div>@enderror
      </div>

      <div>
        <label class="text-xs text-gray-500">Entrega</label>
        <select name="tipo_entrega" class="w-full mt-1 border rounded px-3 py-2">
          <option value="pickup" @selected(old('tipo_entrega')==='pickup')>Pickup</option>
          <option value="delivery" @selected(old('tipo_entrega')==='delivery')>Delivery</option>
        </select>
        @error('tipo_entrega')<div class="text-xs text-red-600 mt-1">{{ $message }}</div>@enderror
      </div>

      <div>
        <label class="text-xs text-gray-500">Nota (opcional)</label>
        <textarea name="nota" rows="3" class="w-full mt-1 border rounded px-3 py-2">{{ old('nota') }}</textarea>
      </div>

      <button class="w-full bg-black text-white rounded py-2">Confirmar pedido</button>
    </form>
  </div>
</div>
@endsection
