@extends('layouts.app', ['title' => 'Gracias'])

@section('content')
<div class="bg-white border rounded p-6">
  <h1 class="text-2xl font-bold">¡Pedido recibido!</h1>
  <p class="mt-2 text-gray-700">Folio: <span class="font-mono font-semibold">{{ $orden->folio }}</span></p>
  <p class="mt-2 text-gray-700">Estatus: <span class="font-semibold">{{ $orden->status }}</span></p>

  <div class="mt-6">
    <a class="inline-block px-4 py-2 rounded bg-black text-white" href="{{ route('orders.track', $orden->folio) }}">Ver seguimiento</a>
    <a class="inline-block px-4 py-2 rounded bg-gray-900 text-white ml-2" href="{{ route('store.index') }}">Seguir comprando</a>
  </div>
</div>
@endsection
