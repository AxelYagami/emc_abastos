@extends('layouts.app', ['title' => 'Seguimiento'])

@section('content')
<div class="bg-white border rounded p-6">
  <h1 class="text-2xl font-bold">Seguimiento</h1>
  <p class="mt-2">Folio: <span class="font-mono font-semibold">{{ $orden->folio }}</span></p>
  <p class="mt-2">Estatus: <span class="font-semibold">{{ $orden->status }}</span></p>

  @if($canSeePII)
    <div class="mt-4 p-3 rounded bg-gray-50 border text-sm">
      <div><span class="text-gray-500">Nombre:</span> {{ $orden->comprador_nombre }}</div>
      <div><span class="text-gray-500">WhatsApp:</span> {{ $orden->comprador_whatsapp }}</div>
      @if($orden->comprador_email)<div><span class="text-gray-500">Email:</span> {{ $orden->comprador_email }}</div>@endif
    </div>
  @else
    <div class="mt-4 p-3 rounded bg-yellow-50 border border-yellow-200 text-sm text-yellow-900">
      Por privacidad, los datos del comprador solo se muestran en el mismo dispositivo donde se creó el pedido.
    </div>
  @endif

  <h2 class="mt-6 font-semibold">Items</h2>
  <div class="mt-2 text-sm space-y-1">
    @foreach($orden->items as $it)
      <div class="flex justify-between">
        <div>{{ $it->nombre ?? $it->producto?->nombre }} <span class="text-gray-500">x{{ $it->cantidad }}</span></div>
        <div class="font-medium">${{ number_format($it->total,2) }}</div>
      </div>
    @endforeach
  </div>
</div>
@endsection
