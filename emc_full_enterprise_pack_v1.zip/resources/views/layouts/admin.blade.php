<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ $title ?? 'Admin · EMC' }}</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-100 text-gray-900">
  <div class="flex min-h-screen">
    <aside class="w-64 bg-white border-r hidden md:block">
      <div class="p-4 font-bold text-lg">Admin</div>
      <div class="px-3 pb-4 text-xs text-gray-500">
        Empresa: {{ session('empresa_nombre') ?? ('#'.(session('empresa_id') ?? '—')) }}
      </div>
      <nav class="px-2 space-y-1 text-sm">
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.dashboard') }}">Dashboard</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.productos.index') }}">Productos</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.categorias.index') }}">Categorías</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.clientes.index') }}">Clientes</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.whatsapp.index') }}">WhatsApp</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.caja.index') }}">Caja</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('admin.inventarios.index') }}">Inventario</a>
        <div class="h-px bg-gray-200 my-2"></div>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('ops.hub') }}">Operaciones</a>
        <a class="block px-3 py-2 rounded hover:bg-gray-100" href="{{ route('store.index') }}">Ver tienda</a>
      </nav>
    </aside>
    <div class="flex-1">
      <header class="bg-white border-b">
        <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div class="font-semibold">{{ $header ?? 'Panel Admin' }}</div>
          <div class="flex items-center gap-2">
            <a class="px-3 py-2 rounded hover:bg-gray-100 text-sm" href="{{ route('empresa.switch') }}">Cambiar empresa</a>
            <form method="POST" action="{{ route('logout') }}">
              @csrf
              <button class="px-3 py-2 rounded hover:bg-gray-100 text-sm">Salir</button>
            </form>
          </div>
        </div>
      </header>

      <main class="max-w-6xl mx-auto px-4 py-6">
        @if(session('ok'))
          <div class="mb-3 p-3 rounded bg-green-50 border border-green-200 text-green-800">{{ session('ok') }}</div>
        @endif
        @if(session('error'))
          <div class="mb-3 p-3 rounded bg-red-50 border border-red-200 text-red-800">{{ session('error') }}</div>
        @endif

        @yield('content')
      </main>
    </div>
  </div>
</body>
</html>
