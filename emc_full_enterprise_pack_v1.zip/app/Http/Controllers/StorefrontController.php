<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use App\Models\Categoria;
use Illuminate\Http\Request;

class StorefrontController extends Controller
{
    public function index(Request $request)
    {
        $empresaId = (int) ($request->query('empresa_id') ?? $request->session()->get('empresa_id'));
        if (!$empresaId) $empresaId = (int) (\DB::table('empresas')->orderBy('id')->value('id') ?? 0);

        $q = Producto::query()->where('empresa_id',$empresaId)->where('activo',true)->with('categoria')->orderByDesc('id');

        $cat = $request->query('cat');
        if ($cat) $q->where('categoria_id',(int)$cat);

        $search = trim((string)$request->query('q',''));
        if ($search !== '') {
            $search = mb_substr(preg_replace('/[%_]+/u',' ', $search), 0, 80);
            $q->where('nombre','ilike',"%{$search}%");
        }

        $productos = $q->paginate(12)->withQueryString();

        $catQ = Categoria::query()->where('empresa_id',$empresaId)->where('activa',true);
        $categorias = $catQ->orderByRaw('orden NULLS LAST')->orderBy('id')->get();

        return view('store.index', compact('productos','categorias','empresaId','search','cat'));
    }

    public function producto(Request $request, int $id)
    {
        $producto = Producto::with('categoria')->findOrFail($id);
        return view('store.producto', compact('producto'));
    }
}
