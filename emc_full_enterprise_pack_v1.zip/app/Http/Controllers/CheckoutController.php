<?php

namespace App\Http\Controllers;

use App\Models\Orden;
use App\Models\OrdenItem;
use App\Models\Producto;
use App\Models\Cliente;
use App\Services\InventarioService;
use App\Services\WhatsApp\OrderWhatsAppNotifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CheckoutController extends Controller
{
    private function getCart(Request $request): array
    {
        return $request->session()->get('cart_v2', ['empresa_id' => null, 'items' => []]);
    }

    public function show(Request $request)
    {
        $cart = $this->getCart($request);
        if (empty($cart['items'])) return redirect()->route('store.index')->with('error','Tu carrito está vacío');

        $products = Producto::whereIn('id', array_keys($cart['items']))->get()->keyBy('id');
        $items = [];
        $total = 0;

        foreach ($cart['items'] as $pid => $qty) {
            $p = $products->get((int)$pid);
            if (!$p) continue;
            $line = (float)$p->precio * (int)$qty;
            $total += $line;
            $items[] = ['producto'=>$p, 'qty'=>(int)$qty, 'line_total'=>$line];
        }

        return view('store.checkout', compact('items','total'));
    }

    public function place(Request $request, InventarioService $inv, OrderWhatsAppNotifier $wa)
    {
        $cart = $this->getCart($request);
        if (empty($cart['items'])) return redirect()->route('store.index')->with('error','Tu carrito está vacío');

        $data = $request->validate([
            'comprador_nombre' => 'required|string|max:180',
            'comprador_email' => 'nullable|email|max:190',
            'comprador_whatsapp' => 'required|string|max:30',
            'tipo_entrega' => 'required|in:pickup,delivery',
            'nota' => 'nullable|string|max:500',
        ]);

        $empresaId = (int)($cart['empresa_id'] ?? 0);
        if (!$empresaId) return redirect()->route('store.index')->with('error','Carrito inválido (empresa)');

        $products = Producto::whereIn('id', array_keys($cart['items']))
            ->where('empresa_id', $empresaId)
            ->where('activo', true)
            ->get()
            ->keyBy('id');

        $itemsPayload = [];
        $subtotal = 0;

        foreach ($cart['items'] as $pid => $qty) {
            $p = $products->get((int)$pid);
            if (!$p) continue;
            $qty = (int)$qty;

            // Inventario: validación simple (si hay inventario, respeta; si no hay, permite)
            if (!$inv->hasStock($empresaId, $p->id, $qty)) {
                return redirect()->route('cart.index')->with('error',"Sin stock suficiente para {$p->nombre}");
            }

            $line = (float)$p->precio * $qty;
            $subtotal += $line;
            $itemsPayload[] = [$p, $qty, $line];
        }

        if (empty($itemsPayload)) return redirect()->route('store.index')->with('error','Carrito inválido');

        return DB::transaction(function () use ($request, $empresaId, $data, $itemsPayload, $subtotal, $inv, $wa) {

            $folio = 'EMC-'.strtoupper(Str::random(14));
            $trackingToken = Str::random(48);
            while (Orden::where('empresa_id',$empresaId)->where('folio',$folio)->exists()) {
                $folio = 'EMC-'.strtoupper(Str::random(14));
            }

            // Cliente maestro por empresa (para opt-out)
            $cliente = Cliente::upsertFromCheckout($empresaId, $data['comprador_nombre'], $data['comprador_whatsapp'], $data['comprador_email'] ?? null);

            $orden = Orden::create([
                'empresa_id' => $empresaId,
                'usuario_id' => null,
                'cliente_id' => $cliente->id,
                'folio' => $folio,
                'tracking_token' => $trackingToken,
                'status' => 'nuevo',
                'tipo_entrega' => $data['tipo_entrega'],
                'comprador_nombre' => $data['comprador_nombre'],
                'comprador_whatsapp' => $data['comprador_whatsapp'],
                'comprador_email' => $data['comprador_email'] ?? null,
                'subtotal' => $subtotal,
                'descuento' => 0,
                'envio' => 0,
                'total' => $subtotal,
                'meta' => ['nota' => $data['nota'] ?? null],
            ]);

            foreach ($itemsPayload as [$p, $qty, $line]) {
                OrdenItem::create([
                    'empresa_id' => $orden->empresa_id,
                    'orden_id' => $orden->id,
                    'producto_id' => $p->id,
                    'nombre' => $p->nombre,
                    'precio' => $p->precio,
                    'cantidad' => $qty,
                    'total' => $line,
                ]);

                // Ledger inventario (venta)
                $inv->venta($empresaId, $p->id, $qty, $orden->id);
            }

            $request->session()->put('last_order_tracking', [
                'folio' => $orden->folio,
                'token' => $trackingToken,
            ]);
            $request->session()->forget('cart_v2');

            // WhatsApp: crea logs + dispara job (si está configurado)
            $wa->onCreated($orden);

            return redirect()->route('orders.thanks', ['folio'=>$orden->folio]);
        });
    }
}
