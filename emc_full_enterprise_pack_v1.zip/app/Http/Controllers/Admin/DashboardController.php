<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Orden;
use App\Models\Producto;
use App\Models\Cliente;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');

        $start = now()->startOfDay();
        $end = now()->endOfDay();

        $ventasHoy = (float) Orden::where('empresa_id',$empresaId)->whereBetween('created_at',[$start,$end])->sum('total');
        $ordenesHoy = (int) Orden::where('empresa_id',$empresaId)->whereBetween('created_at',[$start,$end])->count();
        $productosActivos = (int) Producto::where('empresa_id',$empresaId)->where('activo',true)->count();
        $clientes = (int) Cliente::where('empresa_id',$empresaId)->count();

        $ultimasOrdenes = Orden::where('empresa_id',$empresaId)->orderByDesc('id')->limit(8)->get();

        $kpis = [
            'ventas_hoy' => $ventasHoy,
            'ordenes_hoy' => $ordenesHoy,
            'productos_activos' => $productosActivos,
            'clientes' => $clientes,
        ];

        return view('admin.dashboard', compact('kpis','ultimasOrdenes'));
    }
}
