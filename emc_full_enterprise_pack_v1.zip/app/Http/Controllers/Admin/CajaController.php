<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CajaTurno;
use App\Models\CajaMovimiento;
use Illuminate\Http\Request;

class CajaController extends Controller
{
    public function index(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');

        $turno = CajaTurno::where('empresa_id',$empresaId)->where('status','abierto')->orderByDesc('id')->first();
        $movs = CajaMovimiento::where('empresa_id',$empresaId)->orderByDesc('id')->limit(25)->get();

        return view('admin.caja.index', compact('turno','movs'));
    }

    public function abrir(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $exists = CajaTurno::where('empresa_id',$empresaId)->where('status','abierto')->exists();
        if ($exists) return back()->with('error','Ya hay un turno abierto');

        $t = CajaTurno::create([
            'empresa_id'=>$empresaId,
            'status'=>'abierto',
            'abierto_at'=>now(),
            'actor_usuario_id'=>auth()->id(),
            'meta'=>[],
        ]);

        return redirect()->route('admin.caja.turno',$t->id)->with('ok','Turno abierto');
    }

    public function cerrar(Request $request, int $turnoId)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $turno = CajaTurno::where('empresa_id',$empresaId)->findOrFail($turnoId);
        $turno->status = 'cerrado';
        $turno->cerrado_at = now();
        $turno->save();

        return back()->with('ok','Turno cerrado');
    }

    public function turno(Request $request, int $turnoId)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $turno = CajaTurno::where('empresa_id',$empresaId)->findOrFail($turnoId);
        $movs = CajaMovimiento::where('empresa_id',$empresaId)->where('turno_id',$turno->id)->orderByDesc('id')->limit(200)->get();

        $breakdown = [
            'cash' => (float) CajaMovimiento::where('empresa_id',$empresaId)->where('turno_id',$turno->id)->where('metodo','cash')->sum('monto'),
            'card' => (float) CajaMovimiento::where('empresa_id',$empresaId)->where('turno_id',$turno->id)->where('metodo','card')->sum('monto'),
            'transfer' => (float) CajaMovimiento::where('empresa_id',$empresaId)->where('turno_id',$turno->id)->where('metodo','transfer')->sum('monto'),
        ];

        return view('admin.caja.turno', compact('turno','movs','breakdown'));
    }

    public function movimiento(Request $request, int $turnoId)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $turno = CajaTurno::where('empresa_id',$empresaId)->findOrFail($turnoId);

        $data = $request->validate([
            'tipo' => 'required|in:venta,ingreso,egreso',
            'metodo' => 'required|in:cash,card,transfer',
            'monto' => 'required|numeric',
            'nota' => 'nullable|string|max:255',
        ]);

        CajaMovimiento::create([
            'empresa_id'=>$empresaId,
            'turno_id'=>$turno->id,
            'tipo'=>$data['tipo'],
            'metodo'=>$data['metodo'],
            'monto'=>$data['monto'],
            'nota'=>$data['nota'] ?? null,
            'actor_usuario_id'=>auth()->id(),
        ]);

        return back()->with('ok','Movimiento registrado');
    }

    public function history(Request $request)
    {
        $empresaId = (int) $request->session()->get('empresa_id');
        $q = CajaMovimiento::where('empresa_id',$empresaId)->orderByDesc('id');

        if ($from = $request->get('from')) $q->whereDate('created_at','>=',$from);
        if ($to = $request->get('to')) $q->whereDate('created_at','<=',$to);
        if ($metodo = $request->get('metodo')) $q->where('metodo',$metodo);

        $movs = $q->paginate(30)->withQueryString();
        return view('admin.caja.history', compact('movs'));
    }
}
