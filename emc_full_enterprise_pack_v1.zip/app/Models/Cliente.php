<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $table = 'clientes';
    protected $guarded = [];
    protected $casts = ['enviar_estatus'=>'boolean'];

    public static function upsertFromCheckout(int $empresaId, string $nombre, string $whatsapp, ?string $email): self
    {
        $q = self::where('empresa_id',$empresaId)->where('whatsapp',$whatsapp);
        $existing = $q->first();
        if ($existing) {
            $existing->nombre = $nombre;
            if ($email) $existing->email = $email;
            $existing->save();
            return $existing;
        }

        return self::create([
            'empresa_id'=>$empresaId,
            'nombre'=>$nombre,
            'whatsapp'=>$whatsapp,
            'email'=>$email,
            'enviar_estatus'=>true,
        ]);
    }
}
