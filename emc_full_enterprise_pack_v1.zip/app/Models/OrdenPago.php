<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrdenPago extends Model
{
    protected $table = 'orden_pagos';
    protected $guarded = [];
    protected $casts = ['meta'=>'array'];
}
