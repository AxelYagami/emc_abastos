<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Orden extends Model
{
    protected $table = 'ordenes';
    protected $guarded = [];
    protected $casts = ['meta'=>'array'];

    public function items() { return $this->hasMany(OrdenItem::class, 'orden_id'); }
    public function pagos() { return $this->hasMany(OrdenPago::class, 'orden_id'); }
    public function cliente() { return $this->belongsTo(Cliente::class, 'cliente_id'); }
}
