<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\StorefrontController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\OrderStatusController;
use App\Http\Controllers\EmpresaSwitchController;
use App\Http\Controllers\Auth\LoginController;

use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\ProductosController;
use App\Http\Controllers\Admin\CategoriasController;
use App\Http\Controllers\Admin\ClientesController;
use App\Http\Controllers\Admin\WhatsAppController as AdminWhatsAppController;
use App\Http\Controllers\Admin\InventariosController;
use App\Http\Controllers\Admin\CajaController;

use App\Http\Controllers\Operaciones\OpsHubController;
use App\Http\Controllers\Operaciones\OrdenesController;
use App\Http\Controllers\Operaciones\OrdenPagosController;
use App\Http\Controllers\Operaciones\WhatsAppRetryController;

Route::get('/', [StorefrontController::class,'index'])->name('store.index');
Route::get('/producto/{id}', [StorefrontController::class,'producto'])->name('store.producto');

Route::get('/carrito', [CartController::class,'index'])->name('cart.index');
Route::post('/carrito/agregar', [CartController::class,'add'])->name('cart.add');
Route::post('/carrito', [CartController::class,'update'])->name('cart.update');
Route::post('/carrito/vaciar', [CartController::class,'clear'])->name('cart.clear');

Route::get('/checkout', [CheckoutController::class,'show'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class,'place'])->name('checkout.place');

Route::get('/pedido/{folio}/gracias', [OrderStatusController::class,'thanks'])->name('orders.thanks');
Route::get('/pedido/{folio}', [OrderStatusController::class,'track'])->name('orders.track');

Route::get('/login',[LoginController::class,'showLoginForm'])->name('login');
Route::post('/login',[LoginController::class,'login']);
Route::post('/logout',[LoginController::class,'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/empresa', [EmpresaSwitchController::class, 'index'])->name('empresa.switch');
    Route::post('/empresa', [EmpresaSwitchController::class, 'set'])->name('empresa.set');

    Route::middleware(['empresa'])->group(function () {

        Route::prefix('admin')->name('admin.')->middleware(['role:admin_empresa,superadmin'])->group(function () {
            Route::get('/', [AdminDashboardController::class,'index'])->name('dashboard');

            Route::resource('productos', ProductosController::class)->except(['show']);
            Route::resource('categorias', CategoriasController::class)->except(['show']);

            Route::get('clientes', [ClientesController::class,'index'])->name('clientes.index');
            Route::get('clientes/{id}', [ClientesController::class,'show'])->name('clientes.show');
            Route::post('clientes/{id}/toggle', [ClientesController::class,'toggle'])->name('clientes.toggle');

            Route::get('whatsapp', [AdminWhatsAppController::class,'index'])->name('whatsapp.index');
            Route::get('whatsapp/create', [AdminWhatsAppController::class,'create'])->name('whatsapp.create');
            Route::post('whatsapp', [AdminWhatsAppController::class,'store'])->name('whatsapp.store');
            Route::post('whatsapp/{id}/toggle', [AdminWhatsAppController::class,'toggle'])->name('whatsapp.toggle');
            Route::delete('whatsapp/{id}', [AdminWhatsAppController::class,'destroy'])->name('whatsapp.destroy');

            Route::get('inventarios', [InventariosController::class,'index'])->name('inventarios.index');
            Route::get('inventarios/{productoId}/kardex', [InventariosController::class,'kardex'])->name('inventarios.kardex');
            Route::post('inventarios/{productoId}/ajustar', [InventariosController::class,'ajustar'])->name('inventarios.ajustar');

            Route::get('caja', [CajaController::class,'index'])->name('caja.index');
            Route::post('caja/abrir', [CajaController::class,'abrir'])->name('caja.abrir');
            Route::post('caja/{turnoId}/cerrar', [CajaController::class,'cerrar'])->name('caja.cerrar');
            Route::get('caja/{turnoId}', [CajaController::class,'turno'])->name('caja.turno');
            Route::post('caja/{turnoId}/movimiento', [CajaController::class,'movimiento'])->name('caja.movimiento');
            Route::get('caja-history', [CajaController::class,'history'])->name('caja.history');
        });

        Route::prefix('ops')->name('ops.')->middleware(['role:operaciones,admin_empresa,superadmin'])->group(function () {
            Route::get('/', [OpsHubController::class,'index'])->name('hub');

            Route::get('ordenes/hoy', [OrdenesController::class,'hoy'])->name('ordenes.hoy');
            Route::get('ordenes', [OrdenesController::class,'index'])->name('ordenes.index');
            Route::get('ordenes/{id}', [OrdenesController::class,'show'])->name('ordenes.show');
            Route::post('ordenes/{id}/status', [OrdenesController::class,'updateStatus'])->name('ordenes.status');

            Route::post('ordenes/{ordenId}/pagos', [OrdenPagosController::class,'store'])->name('pagos.store');

            Route::get('whatsapp', [WhatsAppRetryController::class,'index'])->name('whatsapp.index');
            Route::post('whatsapp/{logId}/retry', [WhatsAppRetryController::class,'retry'])->name('whatsapp.retry');
            Route::post('ordenes/{ordenId}/whatsapp/retry-last', [WhatsAppRetryController::class,'retryLast'])->name('whatsapp.retryLast');
            Route::post('ordenes/{ordenId}/whatsapp/optout', [WhatsAppRetryController::class,'optout'])->name('whatsapp.optout');
        });
    });
});
